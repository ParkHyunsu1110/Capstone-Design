package com.example.lovebaby.Model;

public class UserModel {
    public String username;
    public String nickname;
    public String uid;
    public String profileImageUrl;
    public String pushToken;
    public String partneruid;
}
