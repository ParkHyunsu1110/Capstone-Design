package com.example.lovebaby.Model;

public class DayAnalysisModel {
    public String uid;
    public String babyName;
    public int gaewol;
    public int numNap;
    public String timeNap;
    public String timeSleep;
}
