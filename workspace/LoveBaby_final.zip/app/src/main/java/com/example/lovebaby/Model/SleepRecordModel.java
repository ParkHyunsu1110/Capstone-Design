package com.example.lovebaby.Model;

import java.util.Date;

public class SleepRecordModel {
    public String startTime;
    public String runningTime;
    public String uid;
    public String babyName;
    public Date date;
    public Boolean isNap;
}
