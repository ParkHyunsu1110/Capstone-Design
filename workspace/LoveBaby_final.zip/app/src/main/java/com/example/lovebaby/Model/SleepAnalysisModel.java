package com.example.lovebaby.Model;

public class SleepAnalysisModel {
    public int gaewol;
    public int numNap;
    public String timeNap;
    public String timeSleep;
    public int daycnt;
    public String uid;


    public SleepAnalysisModel(){

    }


}
