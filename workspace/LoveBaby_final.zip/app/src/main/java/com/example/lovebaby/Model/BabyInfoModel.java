package com.example.lovebaby.Model;

public class BabyInfoModel {
    //imageuri, name, sex, birthday, birth time, bloodtype
    public String imageUrl;
    public String imageName;
    public String name;
    public String sex;
    public String birthday;
    public String birthtime;
    public String bloodtype;
    public String uid;
    public String userId;
}
