package com.example.lovebaby.Model;

public class MyBoardModel {
    public String imageUri;
    public String imageName;
    public String title;
    public String description;
    public String uid;
    public String userId;
    public String babyname;
}
