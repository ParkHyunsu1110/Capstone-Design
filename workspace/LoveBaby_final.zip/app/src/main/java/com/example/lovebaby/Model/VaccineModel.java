package com.example.lovebaby.Model;

public class VaccineModel {
    public String uidandvaccinename;
    public String date;
    public String time;
    public String facilityname;
    public String reserve_state;

    public String getUidandvaccinename() {
        return uidandvaccinename;
    }

    public void setUidandvaccinename(String uidandvaccinename) {
        this.uidandvaccinename = uidandvaccinename;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getFacilityname() {
        return facilityname;
    }

    public void setFacilityname(String facilityname) {
        this.facilityname = facilityname;
    }

    public String getReserve_state() {
        return reserve_state;
    }

    public void setReserve_state(String reserve_state) {
        this.reserve_state = reserve_state;
    }
}
